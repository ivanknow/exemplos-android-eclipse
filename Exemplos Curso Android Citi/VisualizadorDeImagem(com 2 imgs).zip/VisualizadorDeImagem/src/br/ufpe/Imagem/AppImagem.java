package br.ufpe.Imagem;



import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class AppImagem extends Activity {
	
	Button btn1,btn2;
	ImageView img;
	TextView ed;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        btn1 = (Button) findViewById(R.id.btnImg1);
        btn2 = (Button) findViewById(R.id.btnImg2);
        img = (ImageView) findViewById(R.id.imageView1);
        ed = (TextView) findViewById(R.id.textView1);
       
        
        btn1.setOnClickListener(new OnClickListener() {
			
			public void onClick(View v) {
				img.setImageResource(R.drawable.coala);
				ed.setText("Coala");
			}
        });
        
        btn2.setOnClickListener(new OnClickListener() {
			
			public void onClick(View v) {
				img.setImageResource(R.drawable.farol);
	
				ed.setText("Farol");
			}
        });
    }
}